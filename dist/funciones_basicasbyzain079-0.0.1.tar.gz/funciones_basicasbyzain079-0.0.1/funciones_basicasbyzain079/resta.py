def restar(x,y):
    r=x-y
    return r