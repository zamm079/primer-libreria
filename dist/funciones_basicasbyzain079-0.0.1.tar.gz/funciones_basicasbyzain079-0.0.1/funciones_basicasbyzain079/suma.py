def sumar(x,y):
    r=x+y
    return r