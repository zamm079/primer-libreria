def multiplicacion(x,y):
    r=x*y
    return r