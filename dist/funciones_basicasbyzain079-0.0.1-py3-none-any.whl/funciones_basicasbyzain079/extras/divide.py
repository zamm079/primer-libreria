def division(x,y):
    r=x/y
    return r